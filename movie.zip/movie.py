movie_name="diya"
ticket_price=300
number_of_tickets=2
customer='rupa'
print("Movie Name:", movie_name)
print("Ticket Price:", ticket_price)
print("Number of Tickets:", number_of_tickets )
print("Customer:", customer)
